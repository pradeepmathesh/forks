#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <sys/time.h>
//~ #include <sys/resource.h>
//~ #include <sys/stat.h>
using namespace std;

#include "trie.h"

char* strupr(char *s) {
    char *ss;
    for (ss = s; *s = toupper(*s); s++);
    return ss;
}

int init_spell()  {
    struct timezone tz;    
    struct timeval start, start2, end;
    char fileName[25], s[80], ch;
    int i, lineNum = 1;
    gettimeofday(&start,&tz);
    ifstream dictionary("/usr/share/dict/words");
    if (dictionary.fail()) {
       cerr << "Cannot open 'dictionary'\n";
       exit(-1);
    }
    dictionary >> s;
   // Trie trie(strupr(s));   // initialize root;
    while (dictionary >> s) // initialize trie;
        trie.insert(strupr(s));
    gettimeofday(&end,&tz);
    printf("Time to populate: %i milliseconds.\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000);

    gettimeofday(&start,&tz);
    cout << "Misspelled words:\n";
        if (!trie.wordFound(strupr(s))){
        //     continue;
	cout << s << endl;//" on line " << lineNum << endl;
	}
    dictionary.close();
    gettimeofday(&end,&tz);
    printf("Time to spellcheck: %i milliseconds.\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000);
    return 0;
}
