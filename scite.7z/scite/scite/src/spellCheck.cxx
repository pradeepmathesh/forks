#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <sys/time.h>
//~ #include <sys/resource.h>
//~ #include <sys/stat.h>
using namespace std;

#include "trie.h"

char* strupr(char *s) {
    char *ss;
    for (ss = s; *s = toupper(*s); s++);
    return ss;
}

int main(int argc, char* argv[])  {
    struct timezone tz;    
    struct timeval start, start2, end;
    char fileName[25], s[80], ch;
    int i, lineNum = 1;
    gettimeofday(&start,&tz);
  //  ifstream dictionary("/usr/share/dict/words1");
//    ifstream dictionary("/usr/share/dict/words");
    ifstream dictionary("/home/pradeep/sc1/words2");
    if (dictionary.fail()) {
       cerr << "Cannot open 'dictionary'\n";
       exit(-1);
    }
    dictionary >> s;
    Trie trie(strupr(s));   // initialize root;
long long co=0;
srand(time(NULL));
    while (dictionary >> s) // initialize trie;
	    {
	    if(1){
        trie.insert(strupr(s));
	    co++;
	    }
	    cout<<co<<"\r";
    }
cout<<endl;
    gettimeofday(&end,&tz);
    printf("Time to populate: %i milliseconds.\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000);

    //trie.printTrie();
    //~ if (argc != 2) {
         //~ cout << "Enter a file name: ";
         //~ cin  >> fileName;
    //~ }
    //~ else 
    gettimeofday(&start,&tz);
    strcpy(fileName,"/home/pradeep/sc1/words1_2");
    ifstream textFile(fileName);
    if (textFile.fail()) {
       cout << "Cannot open " << fileName << endl;
       exit(-1);
    }
    cout << "Misspelled words:\n";
    //~ textFile.get(ch);
    //~ while (!textFile.eof()) {
        //~ while (true)
             //~ if (!textFile.eof() && !isalpha(ch)) { // skip non-letters
                  //~ if (ch == '\n')
                        //~ lineNum++;
                  //~ textFile.get(ch);
             //~ }
             //~ else break;
        //~ if (textFile.eof())       // spaces at the end of textFile;
             //~ break;
        //~ for (i = 0; !textFile.eof() && isalpha(ch); i++) {
             //~ s[i] = toupper(ch);
             //~ textFile.get(ch);
        //~ }
        //~ s[i] = '\0';
        //~ if (!trie.wordFound(s))
             //~ continue;
//~ //cout << s << " on line " << lineNum << endl;
    //~ }
        //~ while (textFile >> s) // initialize trie;
	    //~ {
	     //~ if (!trie.wordFound(strupr(s))){
	     //~ cout << s << " on line " << lineNum << endl;
	     //~ }
	    //~ }
    	     if (!trie.wordFound("thank")){
	     cout << s << " on line " << lineNum << endl;
	     }
    dictionary.close();
    textFile.close();
    gettimeofday(&end,&tz);
    printf("Time to spellcheck: %i milliseconds.\n", (end.tv_sec - start.tv_sec) * 1000 + (end.tv_usec - start.tv_usec) / 1000);
    return 0;
}
